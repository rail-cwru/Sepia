Welcome to Sepia.
See doc/manual.html for instructions.

To get started right away, try java -cp "Sepia.jar" edu.cwru.sepia.Main2 data/exampleLaunchConfig.xml
or see doc/edu/cwru/sepia/Main2.html for the javadoc for the primary launcher.


